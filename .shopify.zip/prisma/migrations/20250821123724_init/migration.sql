-- AlterTable
ALTER TABLE "public"."ImportSession" ADD COLUMN     "currentProduct" TEXT;
