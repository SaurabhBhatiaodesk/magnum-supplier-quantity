/// <reference types="@remix-run/dev" />
/// <reference types="@remix-run/node" />

declare module "@remix-run/server-runtime" {
  export interface AppLoadContext {
    // Add any custom context properties here
  }
}