import { useEffect, useMemo, useState } from "react";
import {
  Page,
  Layout,
  Card,
  Text,
  Box,
  BlockStack,
  InlineStack,
  Button,
  Select,
  TextField,
  Icon,
  ChoiceList,
  ButtonGroup,
  Divider,
  RadioButton,
  InlineGrid,
} from "@shopify/polaris";
import { useNavigate } from "@remix-run/react";
import {
  ArrowLeftIcon,
  ArrowRightIcon,
  DeleteIcon,
  PlusIcon,
  SettingsIcon,
} from "@shopify/polaris-icons";

// ----- constants / options -----
const FIELD_OPTIONS = [
  { label: "Tag", value: "tag" },
  { label: "Type", value: "type" },
  { label: "Vendor", value: "vendor" },
  { label: "Price", value: "price" },
  { label: "Cost Price", value: "cost_price" },
  { label: "Retail Price", value: "retail_price" },
  { label: "Weight", value: "weight" },
  { label: "Inventory quantity", value: "inventory" },
  { label: "Product title", value: "title" },
];

const CONDITION_OPTIONS = [
  { label: "is equal to", value: "eq" },
  { label: "is not equal to", value: "neq" },
  { label: "starts with", value: "starts" },
  { label: "ends with", value: "ends" },
  { label: "contains", value: "contains" },
  { label: "does not contain", value: "ncontains" },
  { label: "between", value: "between" },
];

const MARKUP_TYPES = [
  { label: "Percentage", value: "percent" },
  { label: "Fixed Amount", value: "fixed" },
];

const PERCENTAGE_PRESETS = [
  { label: "10%", value: "10" },
  { label: "15%", value: "15" },
  { label: "20%", value: "20" },
  { label: "25%", value: "25" },
  { label: "30%", value: "30" },
  { label: "50%", value: "50" },
  { label: "Custom...", value: "custom" },
];

function uid() {
  return Math.random().toString(36).slice(2);
}

// ----- props -----
interface MarkupConfigurationStepProps {
  apiCredentials: { apiUrl: string; accessToken: string };
  onNext: () => void;
  onPrevious: () => void;
  value?: {
    conditions: Array<{
      id: string;
      field: string;
      operator: string;
      tagText: string;
      markupType: "percent" | "fixed";
      percentagePreset: string;
      customPercent: string;
      value: string;
    }>;
    conditionsType: "all" | "any";
    connector?: "AND" | "OR";
    tieBreaker?: "higher" | "lower" | "priority";
  };
  onChange?: (config: MarkupConfigurationStepProps["value"]) => void;
  selectedFiltersSummary?: Array<{ key: string; values: string[] }>;
}

export default function MarkupConfigurationStep({
  apiCredentials,
  onNext,
  onPrevious,
  value,
  onChange,
  selectedFiltersSummary,
}: MarkupConfigurationStepProps) {
  const navigate = useNavigate();

  type Row = {
    id: string;
    field: string;              // tag, vendor, etc.
    operator: string;           // eq, neq, ...
    tagText: string;            // for text inputs (tag/title/vendor)
    markupType: "percent" | "fixed";
    percentagePreset: string;   // one of presets or 'custom'
    customPercent: string;      // only when preset === 'custom'
    value: string;              // numeric value (for fixed) or readonly for percent
  };

  const MAX_CONDITIONS = 2;

  const [matchMode, setMatchMode] = useState<"all" | "any">(value?.conditionsType ?? "all");
  const [connector, setConnector] = useState<"AND" | "OR">(value?.connector ?? "AND");
  const [rows, setRows] = useState<Row[]>(
    value?.conditions && value.conditions.length > 0
              ? (value.conditions as Row[]).map(c => ({
            ...c,
            operator: (c.field === 'price' || c.field === 'Variant Price' || c.field.toLowerCase().includes('price')) ? 'between' : c.operator // Auto-set between for price fields
          }))
      : [{
          id: uid(),
          field: "tag",
          operator: "eq",
          tagText: "",
          markupType: "percent",
          percentagePreset: "10",
          customPercent: "",
          value: "10",
        }]
  );

  // Sync outward when values change
  useEffect(() => {
    onChange?.({
      conditions: rows,
      conditionsType: matchMode,
      connector,
      tieBreaker: value?.tieBreaker ?? "higher",
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [rows, matchMode, connector]);

  // Build dynamic field options from Step 4 selections + defaults
  const dynamicFieldOptions = useMemo(() => {
    const fromFiltersRaw = (selectedFiltersSummary ?? []).map((g) => ({ label: g.key, value: g.key }));
    const fromFilters = fromFiltersRaw.filter((o) => typeof o.value === 'string' && o.value.trim().length > 0);
    if (fromFilters.length > 0) {
      // Only show selected attributes from Step 4
      const unique: { label: string; value: string }[] = [];
      const seen = new Set<string>();
      for (const opt of fromFilters) {
        if (!seen.has(opt.value)) {
          unique.push(opt);
          seen.add(opt.value);
        }
      }
      return unique.length > 0 ? unique : FIELD_OPTIONS;
    }
    // Fallback to defaults when nothing selected
    return FIELD_OPTIONS;
  }, [selectedFiltersSummary]);

  const fieldOptionsWithPlaceholder = useMemo(() => {
    // Avoid placeholder to reduce edge-cases; return pure list
    return dynamicFieldOptions;
  }, [dynamicFieldOptions]);

  // Ensure current rows use valid fields if options restricted by Step 4
  useEffect(() => {
    if ((selectedFiltersSummary?.length ?? 0) === 0) return;
    const allowed = new Set(dynamicFieldOptions.map(o => o.value));
    setRows(prev => {
      let changed = false;
      const next = prev.map(r => {
        if (!allowed.has(r.field)) {
          const first = dynamicFieldOptions[0]?.value || r.field;
          changed = true;
          return { ...r, field: first };
        }
        return r;
      });
      return changed ? next : prev;
    });
  }, [dynamicFieldOptions, selectedFiltersSummary]);

  const canAddRow = rows.length < MAX_CONDITIONS;

  function addRow() {
    if (!canAddRow) return;
    setRows((prev) => [
      ...prev,
      {
        id: uid(),
        field: "tag",
        operator: "eq",
        tagText: "",
        markupType: "percent",
        percentagePreset: "10",
        customPercent: "",
        value: "10",
      },
    ]);
  }

  function removeRow(id: string) {
    setRows((prev) => {
      const next = prev.filter((r) => r.id !== id);
      // always keep at least one row visible
      if (next.length === 0) {
        return [{
          id: uid(),
          field: "tag",
          operator: "eq",
          tagText: "",
          markupType: "percent",
          percentagePreset: "10",
          customPercent: "",
          value: "10",
        }];
      }
      return next;
    });
  }

  function updateRow(id: string, key: keyof Row, value: string) {
    setRows((prev) => prev.map((r) => (r.id === id ? { ...r, [key]: value } : r)));
  }

  function onChangePercentagePreset(id: string, preset: string) {
    setRows((prev) => prev.map((r) => {
      if (r.id !== id) return r;
      if (preset === "custom") {
        return { ...r, percentagePreset: preset, customPercent: "", value: "" };
      }
      return { ...r, percentagePreset: preset, customPercent: "", value: preset };
    }));
  }

  const previewText = useMemo(() => {
    if (rows.length === 0) return "No conditions";
    const conds = rows.map((r) => {
      const field = FIELD_OPTIONS.find((f) => f.value === r.field)?.label ?? r.field;
      const op = CONDITION_OPTIONS.find((o) => o.value === r.operator)?.label ?? r.operator;
      const lhs = field.toLowerCase();
      
      // Handle price range display
      let rhs = r.tagText ? `"${r.tagText}"` : "\"\"";
      if ((r.field === 'price' || r.field === 'Variant Price' || r.field.toLowerCase().includes('price')) && r.operator === 'between' && r.tagText.includes('-')) {
        const [from, to] = r.tagText.split('-');
        rhs = `"$${from || '0'} to $${to || '0'}"`;
      }
      
      const mark =
        r.markupType === "percent"
          ? `${r.percentagePreset === "custom" ? r.customPercent || "0" : r.percentagePreset}% markup`
          : `${r.value || 0} fixed markup`;
      return `${lhs} ${op} ${rhs} — ${mark}`;
    });
    const joiner = connector === "AND" ? " and " : " or ";
    return `Products must match ${matchMode === "all" ? "all" : "any"} of the following conditions: ` + conds.join(joiner);
  }, [rows, matchMode, connector]);

  // ---- small render helper for a single condition card ----
  function ConditionCard({ row }: { row: Row }) {
    return (
      <Card key={row.id} background="bg-surface-secondary">
        <Box padding="300">
          <BlockStack gap="300">
            <InlineGrid columns={{ xs: 1, md: 3 }} gap="300">
              <Select
                label="Field"
                options={fieldOptionsWithPlaceholder}
                value={fieldOptionsWithPlaceholder.some(o => o.value === row.field) ? row.field : (fieldOptionsWithPlaceholder[0]?.value || 'tag')}
                onChange={(val) => {
                  updateRow(row.id, "field", val);
                  // Auto-set operator to "between" for price fields
                  if (val === 'price' || val === 'Variant Price' || val.toLowerCase().includes('price')) {
                    updateRow(row.id, "operator", "between");
                  }
                }}
              />
              <Select
                label="Condition"
                options={CONDITION_OPTIONS}
                value={row.operator}
                onChange={(val) => updateRow(row.id, "operator", val)}
              />
              <Box>
                <Button
                  icon={DeleteIcon}
                  onClick={() => removeRow(row.id)}
                  accessibilityLabel="Delete condition"
                />
              </Box>
            </InlineGrid>

            {(row.field === 'price' || row.field === 'Variant Price' || row.field.toLowerCase().includes('price')) ? (
              <InlineGrid columns={{ xs: 1, md: 2 }} gap="300">
                <TextField
                  label="From"
                  placeholder="Enter minimum price"
                  value={row.tagText.split('-')[0] || ''}
                  onChange={(val) => {
                    const currentTo = row.tagText.split('-')[1] || '';
                    updateRow(row.id, "tagText", `${val}-${currentTo}`);
                  }}
                  autoComplete="off"
                  type="number"
                  suffix="$"
                />
                <TextField
                  label="To"
                  placeholder="Enter maximum price"
                  value={row.tagText.split('-')[1] || ''}
                  onChange={(val) => {
                    const currentFrom = row.tagText.split('-')[0] || '';
                    updateRow(row.id, "tagText", `${currentFrom}-${val}`);
                  }}
                  autoComplete="off"
                  type="number"
                  suffix="$"
                />
              </InlineGrid>
            ) : (
              <TextField
                label={`Enter ${row.field}`}
                placeholder={`Enter ${row.field}`}
                value={row.tagText}
                onChange={(val) => updateRow(row.id, "tagText", val)}
                autoComplete="off"
              />
            )}

            <InlineGrid columns={{ xs: 1, md: 3 }} gap="300">
              <Select
                label="Markup Type"
                options={MARKUP_TYPES}
                value={row.markupType}
                onChange={(val) => updateRow(row.id, "markupType", val as Row["markupType"])}
              />

              {row.markupType === "percent" ? (
                <Select
                  label="Percentage"
                  options={PERCENTAGE_PRESETS}
                  value={row.percentagePreset}
                  onChange={(val) => onChangePercentagePreset(row.id, val)}
                />
              ) : (
                <TextField
                  label="Value"
                  type="number"
                  value={row.value}
                  onChange={(val) => updateRow(row.id, "value", val)}
                  autoComplete="off"
                  suffix="%"
                />
              )}

              {row.markupType === "percent" && row.percentagePreset !== "custom" ? (
                <TextField
                  label="Value"
                  value={row.value}
                  onChange={(val) => updateRow(row.id, "value", val)}
                  readOnly
                  suffix="%"
                  autoComplete="off"
                />
              ) : row.markupType === "percent" ? (
                <TextField
                  label="Custom %"
                  placeholder="Enter %"
                  type="number"
                  value={row.customPercent}
                  onChange={(val) => updateRow(row.id, "customPercent", val)}
                  suffix="%"
                  autoComplete="off"
                />
              ) : (
                <TextField
                  label="Currency"
                  value={""}
                  onChange={() => { }}
                  readOnly
                  placeholder=""
                  autoComplete="off"
                />
              )}
            </InlineGrid>
          </BlockStack>
        </Box>
      </Card>
    );
  }

  return (
    <Card>
    <Page title="Step 5: Markup Configuration" subtitle="Set up conditions-based markup rules for your products">
      <Layout>
        {selectedFiltersSummary && selectedFiltersSummary.length > 0 && (
          <Layout.Section>
            <Card>
              <div style={{ position: 'relative', zIndex: 1 }}>
              <Box padding="300">
                <BlockStack gap="150">
                  <Text as="h3" variant="headingSm">Selected Filters from Step 4</Text>
                  {selectedFiltersSummary.map((g) => (
                    <Box key={g.key} padding="200" borderColor="border" borderWidth="025" borderRadius="200">
                      <InlineStack align="space-between">
                        <Text as="h4" variant="bodyMd" fontWeight="semibold">{g.key}</Text>
                        <Text as="span" tone="subdued">{g.values.length} selected</Text>
                      </InlineStack>
                      <InlineStack gap="150" wrap>
                        {g.values.map((v) => (
                          <span key={v} style={{background:'#f6f8fb', padding:'4px 8px', borderRadius:12}}>{v}</span>
                        ))}
                      </InlineStack>
                    </Box>
                  ))}
                </BlockStack>
              </Box>
              </div>
            </Card>
          </Layout.Section>
        )}
        <Layout.Section>
          <Card>
            <Box padding="400">
              <BlockStack gap="300">
                <InlineStack gap="200" blockAlign="center">
                  <div>
                    <Icon source={SettingsIcon} tone="info" />
                  </div>
                  <Text as="h3" variant="headingMd">Conditions</Text>
                </InlineStack>

                <InlineStack gap="300" blockAlign="center">
                  <Text as="span">Products must match:</Text>
                  <InlineStack gap="200" blockAlign="center" align="start">
                    <RadioButton
                      label="all conditions"
                      id="match-all"
                      name="match-mode"
                      checked={matchMode === "all"}
                      onChange={(checked) => checked && setMatchMode("all")}
                    />
                    <RadioButton
                      label="any condition"
                      id="match-any"
                      name="match-mode"
                      checked={matchMode === "any"}
                      onChange={(checked) => checked && setMatchMode("any")}
                    />
                  </InlineStack>
                </InlineStack>

                {/* Explanation */}
                <Box padding="300" background="bg-surface-info" borderRadius="300">
                  <BlockStack gap="200">
                    <Text as="h4" variant="headingSm">How it works:</Text>
                    {matchMode === "all" ? (
                      <Text as="p" variant="bodySm">
                        <strong>AND Condition:</strong> All conditions must match. Example: Tag = "premium" AND Tag = "imported" 
                        → Product must have both tags for markup to apply.
                      </Text>
                    ) : (
                      <Text as="p" variant="bodySm">
                        <strong>OR Condition:</strong> Any one condition can match. Example: Tag = "premium" OR Tag = "imported" 
                        → Product needs only one tag for markup to apply.
                      </Text>
                    )}
                  </BlockStack>
                </Box>

                {/* Conditions with centered connector */}
                <BlockStack gap="400">
                  {/* First condition */}
                  {rows[0] && <ConditionCard row={rows[0]} />}

                  {/* AND/OR centered between the two cards */}
                  {rows.length === 2 && (
                    <InlineStack align="center" blockAlign="center" gap="300"  >
                      <div style={{ flex: 1 }}>
                        <Divider />
                      </div>
                      <Select
                        label=""
                        labelHidden
                        options={[{ label: "AND", value: "AND" }, { label: "OR", value: "OR" }]}
                        value={connector}
                        onChange={(v) => setConnector(v as "AND" | "OR")}
                      />
                      <div style={{ flex: 1 }}>
                        <Divider />
                      </div>
                    </InlineStack>
                  )}

                  {/* Second condition */}
                  {rows[1] && <ConditionCard row={rows[1]} />}

                  {/* Add row button – hidden once second form is added */}
                  {canAddRow && (
                    <div>
                      <Button icon={PlusIcon} onClick={addRow}>
                        Add another condition
                      </Button>
                    </div>
                  )}
                </BlockStack>
              </BlockStack>
            </Box>
          </Card>
        </Layout.Section>

        {/* Preview */}
        <Layout.Section>
          <Box padding="300" background="bg-surface-success" borderRadius="300">
            <BlockStack gap="200">
              <Text as="h3" variant="headingSm">Configuration Preview</Text>
              <Text as="p" tone="subdued">{previewText}</Text>
            </BlockStack>
          </Box>
        </Layout.Section>

        {/* Footer */}
        <Layout.Section>
          <ButtonGroup>
            <Button icon={ArrowLeftIcon} onClick={onPrevious}>Previous</Button>
            <Button variant="primary" icon={ArrowRightIcon} onClick={onNext}>Next: Import Settings</Button>
          </ButtonGroup>
        </Layout.Section>
      </Layout>
    </Page>
    </Card>
  );
}

// Small helper to keep 3-column layout like screenshot
function InlineGridLike({ children }: { children: React.ReactNode }) {
  return (
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "1fr 1fr auto",
        gap: "12px",
        alignItems: "end",
      }}
    >
      {children}
    </div>
  );
}
