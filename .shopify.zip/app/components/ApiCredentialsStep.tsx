import { useState, useEffect } from 'react';
import {
  Card,
  Layout,
  Button,
  TextField,
  Select,
  Banner,
  Badge,
  RadioButton,
  BlockStack,
  Text,
  Box,
  Icon,
  Spinner,
  ButtonGroup,
  FormLayout,
  Divider,
  InlineStack,
  InlineGrid
} from '@shopify/polaris';
import {
  CheckCircleIcon,
  AlertCircleIcon,
  ListBulletedIcon,
  ArrowLeftIcon,
  PlusIcon,
  OrganizationIcon,
  EmailIcon,
  UploadIcon,
  FileIcon,
  LinkIcon,
  DatabaseIcon,
  KeyIcon
} from '@shopify/polaris-icons';

type ValidationStatus = 'success' | 'error' | null;

interface Credentials {
  apiUrl: string;
  accessToken: string;
  connectionId?: string;
}

interface ApiCredentialsStepProps {
  credentials: Credentials;
  onCredentialsChange: (next: Credentials) => void;
  onNext: () => void;
  onGoToList?: () => void;
  editingApi?: { name: string } | null;
  onConnectionTypeChange?: (type: 'api' | 'csv') => void;
  onSelectCsvImport?: () => void;
}

export default function ApiCredentialsStep({ credentials, onCredentialsChange, onNext, onGoToList, editingApi = null, onConnectionTypeChange, onSelectCsvImport }: ApiCredentialsStepProps) {
  const [isValidating, setIsValidating] = useState(false);
  const [validationStatus, setValidationStatus] = useState<ValidationStatus>(null); // null, 'success', 'error'
  const [validationMessage, setValidationMessage] = useState<string>('');
  
  // Supplier and connection type management
  const [supplierName, setSupplierName] = useState<string>('');
  const [supplierEmail, setSupplierEmail] = useState<string>('');
  const [connectionType, setConnectionType] = useState<'api' | 'csv'>('api'); // 'api' or 'csv'
  const [csvFile, setCsvFile] = useState<File | null>(null);
  const [selectedSupplier, setSelectedSupplier] = useState<string>('');
  const [savedConnections, setSavedConnections] = useState<any[]>([]);
  const [isLoadingConnections, setIsLoadingConnections] = useState(false);
  
  // Load saved connections from database
  useEffect(() => {
    async function loadConnections() {
      setIsLoadingConnections(true);
      try {
        const resp = await fetch('/app/api/connections');
        const data = await resp.json();
        if (resp.ok && data?.success) {
          setSavedConnections(data.connections || []);
        }
      } catch (error) {
        console.error('Error loading connections:', error);
      } finally {
        setIsLoadingConnections(false);
      }
    }
    loadConnections();
  }, []);
  
  // Build suppliers list from saved connections - deduplicate by supplier email
  const uniqueSuppliers = savedConnections.reduce((acc: any[], conn) => {
    const existingIndex = acc.findIndex(s => s.supplierEmail === conn.supplierEmail);
    if (existingIndex === -1) {
      acc.push({
        label: `${conn.supplierName || conn.name} (${conn.supplierEmail || 'No email'})`,
        value: conn.id,
        supplierName: conn.supplierName || conn.name,
        supplierEmail: conn.supplierEmail
      });
    }
    return acc;
  }, []);

  const suppliers = [
    ...uniqueSuppliers,
    { label: 'Add New Supplier', value: 'add-new' }
  ];

  const handleInputChange = (field: keyof Credentials | 'apiName', value: string) => {
    if (field === 'apiName') return; // not stored in credentials
    onCredentialsChange({
      ...credentials,
      [field]: value
    });
    // Reset validation when inputs change
    setValidationStatus(null);
    setValidationMessage('');
  };

  const handleSupplierChange = (value: string) => {
    setSelectedSupplier(value);
    if (value === 'add-new') {
      setSupplierName('');
      setSupplierEmail('');
      // Clear connectionId for new supplier
      onCredentialsChange({
        ...credentials,
        connectionId: undefined
      });
    } else {
      const supplier = suppliers.find(s => s.value === value);
      if (supplier && 'supplierName' in supplier) {
        setSupplierName(supplier.supplierName || '');
        setSupplierEmail(supplier.supplierEmail || '');
        // Set connectionId for existing supplier
        onCredentialsChange({
          ...credentials,
          connectionId: value
        });
      }
    }
  };

  const handleFileUpload = (files: FileList | null) => {
    const file = files && files[0];
    if (file && file.type === 'text/csv') {
      setCsvFile(file);
    } else {
      // Show error banner
      setValidationStatus('error');
      setValidationMessage('Please select a valid CSV file');
    }
  };

  const validateCredentials = async () => {
    // Check if supplier info is filled
    if (!supplierName || !supplierEmail) {
      setValidationStatus('error');
      setValidationMessage('Please fill in supplier name and email');
      return;
    }

    // Check validation based on connection type
    if (connectionType === 'api') {
      if (!credentials.apiUrl || !credentials.accessToken) {
        setValidationStatus('error');
        setValidationMessage('Please fill in both API URL and access token for API connection');
        return;
      }
    } else if (connectionType === 'csv') {
      if (!csvFile) {
        setValidationStatus('error');
        setValidationMessage('Please upload a CSV file for CSV connection');
        return;
      }
    }

    setIsValidating(true);
    try {
      if (connectionType === 'api') {
        const formData = new FormData();
        formData.append('action', 'validateConnection');
        formData.append('apiUrl', credentials.apiUrl);
        formData.append('accessToken', credentials.accessToken);

        const resp = await fetch('/app/api/external', {
          method: 'POST',
          body: formData
        });

        const data = await resp.json().catch(() => ({}));

        if (resp.ok && data?.success) {
          setValidationStatus('success');
          setValidationMessage('API credentials validated successfully!');
        } else {
          setValidationStatus('error');
          setValidationMessage(
            typeof data?.error === 'string' && data.error
              ? data.error
              : 'Invalid API credentials or unable to reach API.'
          );
        }
      } else if (connectionType === 'csv') {
        if (csvFile && csvFile.type === 'text/csv') {
          setValidationStatus('success');
          setValidationMessage('CSV file validated successfully!');
        } else {
          setValidationStatus('error');
          setValidationMessage('Invalid CSV file. Please upload a valid CSV file.');
        }
      }
    } catch (error: any) {
      setValidationStatus('error');
      setValidationMessage(error?.message || 'Error validating credentials. Please try again.');
    } finally {
      setIsValidating(false);
    }
  };

  const canProceed = validationStatus === 'success';

  const saveConnection = async () => {
    const formData = new FormData();
    formData.append('action', 'create');
    formData.append('data', JSON.stringify({
      type: connectionType,
      name: editingApi?.name || supplierName || 'API Connection',
      apiUrl: connectionType === 'api' ? credentials.apiUrl : null,
      accessToken: connectionType === 'api' ? credentials.accessToken : null,
      csvFileName: connectionType === 'csv' ? csvFile?.name : null,
      supplierName,
      supplierEmail,
      status: 'connected',
      scheduledTime: null,
      productCount: 0,
    }));

    const resp = await fetch('/app/api/connections', {
      method: 'POST',
      body: formData
    });
    
    if (resp.ok) {
      const data = await resp.json();
      if (data.success && data.connection?.id) {
        // Add connectionId to credentials
        onCredentialsChange({
          ...credentials,
          connectionId: data.connection.id
        });
      }
    }
    
    return resp.ok;
  };

  const canValidate = () => {
    const hasSupplierInfo = Boolean(supplierName) && Boolean(supplierEmail);
    if (connectionType === 'api') {
      return hasSupplierInfo && Boolean(credentials.apiUrl) && Boolean(credentials.accessToken);
    } else if (connectionType === 'csv') {
      return hasSupplierInfo && Boolean(csvFile);
    }
    return false; 
  };

  const getBannerStatus = () => {
    switch (validationStatus) {
      case 'success':
        return 'success' as const;
      case 'error':
        return 'critical' as const;
      default:
        return 'info' as const;
    }
  };

  return (
    <Layout>
      <Layout.Section>
        <Card>
          <Box padding="600">
            <BlockStack gap="400"> 
               <InlineStack align="space-between" blockAlign="center">
              <BlockStack>
                <Text as="h1" variant="headingLg">
                  {editingApi ? 'Edit Supplier Connection' : 'Supplier & API Credentials'}
                </Text>
                <Text as="p" variant="bodyMd" tone="subdued">
                  {editingApi 
                    ? `Update connection details for ${editingApi?.name}`
                    : 'Set up your supplier connection using either API integration or CSV import'
                  }
                </Text>
              </BlockStack>
              {onGoToList && (
                <Button  icon={ListBulletedIcon} onClick={onGoToList}>
                  Go to Supplier List
                </Button>
              )}
            </InlineStack>
              {editingApi && (
                <Banner>
                  <p>You are editing an existing supplier connection. Changes will be saved when you validate the credentials.</p>
                </Banner>
              )}
 

              {/* Supplier Information Section */}
              <Card background="bg-surface-secondary">
                <BlockStack > 
                  <div  style={{display:'flex', gap:'2px', marginBottom:'10px'}}> 
                    <div>
                    <Icon source={OrganizationIcon} tone='info' />
                    </div>
                    <Text as="h2" variant="headingMd">Supplier Information</Text>
                    </div> 
                  
                  <FormLayout>
                    <FormLayout.Group>
                      <Select
                        label="Supplier *"
                        options={suppliers}
                        value={selectedSupplier}
                        onChange={handleSupplierChange}
                        placeholder={isLoadingConnections ? "Loading suppliers..." : "Select or add supplier"}
                        disabled={isLoadingConnections}
                      />
                      
                      <TextField
                        label="Supplier Email *"
                        type="email"
                        autoComplete="email"
                        value={supplierEmail}
                        onChange={setSupplierEmail}
                        placeholder="supplier@company.com"
                        prefix={<Icon source={EmailIcon} />}
                      />
                    </FormLayout.Group>

                    {selectedSupplier === 'add-new' && (
                      <TextField
                        label="Supplier Name"
                        value={supplierName}
                        autoComplete="off"
                        onChange={setSupplierName}
                        placeholder="Enter supplier company name"
                      />
                    )}
                  </FormLayout>
                </BlockStack>
              </Card>

              {/* Connection Type Selection */}
              <Card background="bg-surface-secondary">
                <BlockStack>
                    <div style={{display:'flex', gap:'2px', marginBottom:'10px'}}> 
                    <div>
                    <Icon source={DatabaseIcon} tone='magic' />
                    </div>
                    <Text as="h2" variant="headingMd">Connection Type</Text>
                  </div>
                  
                  <BlockStack>
               <InlineGrid gap="400" columns={2}>

                    <RadioButton
                      label="API Connection"
                      checked={connectionType === 'api'}
                      id="api"
                      name="connectionType"
                      onChange={() => {
                        setConnectionType('api');
                        setValidationStatus(null);
                        setValidationMessage('');
                        setCsvFile(null);
                        onConnectionTypeChange?.('api');
                      }}
                    />
                    <RadioButton
                      label="CSV Import"
                      checked={connectionType === 'csv'}
                      id="csv"
                      name="connectionType"
                      onChange={() => {
                        setConnectionType('csv');
                        setValidationStatus(null);
                        setValidationMessage('');
                        onConnectionTypeChange?.('csv');
                        onSelectCsvImport?.();
                      }}
                    />
                    </InlineGrid>
                  </BlockStack>
                </BlockStack>
              </Card>

              {/* API Connection Fields */}
              {connectionType === 'api' && (
                <Card>
                  <BlockStack>
                     <div  style={{display:'flex', gap:'2px', color: '#0094d5', marginBottom:'10px'}}>
                      <div>
                      <Icon source={LinkIcon} tone='info' />
                      </div>
                      <Text as="h2" variant="headingMd">API Connection Details</Text>
                    </div>
                    
                    <FormLayout>
                      {editingApi && (
                        <TextField
                          label="API Name *"
                          value={editingApi?.name || ''}
                          autoComplete="off"
                          onChange={(value) => handleInputChange('apiName', value)}
                          placeholder="Enter a name for this API"
                        />
                      )}
                      
                      <TextField
                        label="API URL *"
                        type="url"
                        autoComplete="url"
                        value={credentials.apiUrl}
                        onChange={(value) => handleInputChange('apiUrl', value)}
                        placeholder="https://api.example.com/products"
                      />
                      
                      <TextField
                        label="Access Token *"
                        type="password"
                        autoComplete="off"
                        value={credentials.accessToken}
                        onChange={(value) => handleInputChange('accessToken', value)}
                        placeholder="Enter your access token"
                        prefix={<Icon source={KeyIcon} />}
                      />
                    </FormLayout>
                  </BlockStack>
                </Card>
              )}

              {/* CSV Connection Fields */}
              {connectionType === 'csv' && (
                <Card>
                  <BlockStack>
                    <BlockStack>
                      <Icon source={DatabaseIcon} />
                      <Text as="h2" variant="headingMd">CSV Import Details</Text>
                    </BlockStack>
                    
                    <BlockStack>
                      <Text as="p" variant="bodyMd">CSV File *</Text>
                      <div>
                        <input
                          type="file"
                          accept=".csv"
                          onChange={(e) => handleFileUpload(e.target.files)}
                          style={{ display: 'none' }}
                          id="csv-upload"
                        />
                        <label htmlFor="csv-upload">
                          <Button icon={UploadIcon}>
                            Choose CSV File
                          </Button>
                        </label>
                      </div>
                      {csvFile && (
                        <Badge tone="success" icon={FileIcon}>
                          {csvFile.name}
                        </Badge>
                      )}
                      <Text as="p" variant="bodySm" tone="subdued">
                        Upload a CSV file with your product data. Accepted format: .csv
                      </Text>
                    </BlockStack>
                  </BlockStack>
                </Card>
              )}

              {validationMessage && (
                <Banner tone={getBannerStatus()}>
                  <p>{validationMessage}</p>
                </Banner>
              )}

              <BlockStack>
                <ButtonGroup>
                  {editingApi && onGoToList && (
                    <Button 
                      icon={ArrowLeftIcon}
                      onClick={onGoToList}
                    >
                      Back to List
                    </Button>
                  )}
                  
                  <Button
                    onClick={validateCredentials}
                    disabled={isValidating || !canValidate()}
                    loading={isValidating}
                  >
                    {editingApi ? 'Update & Validate' : 'Validate Connection'}
                  </Button>
                  
                  <Button
                    variant="primary"
                    onClick={async () => {
                      if (!canProceed) return;
                      const ok = await saveConnection();
                      if (ok) onNext();
                    }}
                    disabled={!canProceed}
                  >
                    {editingApi ? 'Save Changes' : 'Next Step'}
                  </Button>
                </ButtonGroup>
              </BlockStack>
            </BlockStack>
          </Box>
        </Card>
      </Layout.Section>
    </Layout>
  );
}