import { useEffect, useState } from 'react';
import { useNavigate } from '@remix-run/react';
import {
  Page,
  Card,
  Layout,
  Button,
  Badge,
  TextField,
  DataTable,
  BlockStack,
  Text,
  Box,
  Icon,
  EmptyState,
  ButtonGroup,
  InlineGrid,
  InlineStack
} from '@shopify/polaris';
import {
  PlusIcon,
  SearchIcon,
  StoreIcon,
  CheckCircleIcon,
  XCircleIcon,
  ClipboardChecklistIcon,
  StatusActiveIcon,
  DomainLandingPageIcon,
  DatabaseIcon,
  AlertCircleIcon,
  EmailIcon,
  ChevronRightIcon
} from '@shopify/polaris-icons';

interface Supplier {
  id: number;
  name: string;
  email: string;
  website: string;
  status: 'active' | 'inactive' | 'error' | string;
  apiConnections: number;
  csvConnections: number;
  totalProducts: number;
  lastActivity: string;
  connectionTypes: Array<'api' | 'csv'>;
}

interface SupplierListingStepProps {
  onSupplierClick: (supplier: Supplier) => void;
  onAddNewSupplier: () => void;
}

export default function SupplierListingStep({
  onSupplierClick,
  onAddNewSupplier
}: SupplierListingStepProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const navigate = useNavigate();

  // Load saved connections from the database
  type SavedConnection = {
    id: string;
    name: string;
    type: 'api' | 'csv' | string;
    apiUrl?: string | null;
    accessToken?: string | null;
    csvFileName?: string | null;
    status?: string | null;
    updatedAt?: string | null;
    supplierName?: string | null;
    productCount?: number | null;
    scheduleEnabled?: boolean;
    scheduleFrequency?: string;
    scheduleTime?: string;
    scheduledTime?: string | null;
  };
  const [connections, setConnections] = useState<SavedConnection[]>([]);
  const [isLoadingConnections, setIsLoadingConnections] = useState(false);
  const [totalImportedProducts, setTotalImportedProducts] = useState(0);

  function getTimeAgo(dateInput?: string | null) {
    if (!dateInput) return '—';
    const date = new Date(dateInput);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffSec = Math.floor(diffMs / 1000);
    const diffMin = Math.floor(diffSec / 60);
    const diffHr = Math.floor(diffMin / 60);
    const diffDay = Math.floor(diffHr / 24);
    if (diffSec < 60) return 'just now';
    if (diffMin < 60) return `${diffMin} min${diffMin === 1 ? '' : 's'} ago`;
    if (diffHr < 24) return `${diffHr} hour${diffHr === 1 ? '' : 's'} ago`;
    return `${diffDay} day${diffDay === 1 ? '' : 's'} ago`;
  }

  async function loadConnections() {
    setIsLoadingConnections(true);
    try {
      const resp = await fetch('/app/api/connections');
      const data = await resp.json();
      if (resp.ok && data?.success) {
        const rawList: SavedConnection[] = (data.connections || []).map((c: any) => {
          // Parse schedule data
          let scheduleEnabled = false;
          let scheduleFrequency = 'daily';
          let scheduleTime = '09:00';
          
          if (c.scheduledTime) {
            try {
              const scheduleData = JSON.parse(c.scheduledTime);
              if (scheduleData.enabled !== undefined) {
                scheduleEnabled = scheduleData.enabled;
                scheduleFrequency = scheduleData.frequency || 'daily';
                scheduleTime = scheduleData.time || '09:00';
              }
            } catch (e) {
              // If parsing fails, treat as simple time string
              scheduleEnabled = true;
              scheduleTime = c.scheduledTime;
            }
          }
          
          return {
            id: c.id,
            name: c.name,
            type: c.type,
            apiUrl: c.apiUrl ?? null,
            accessToken: c.accessToken ?? null,
            csvFileName: c.csvFileName ?? null,
            status: c.status ?? 'connected',
            updatedAt: c.updatedAt ?? null,
            supplierName: c.supplierName ?? null,
            productCount: c.productCount ?? null,
            scheduleEnabled,
            scheduleFrequency,
            scheduleTime,
            scheduledTime: c.scheduledTime
          };
        });
        
        // Remove duplicates based on supplier name and API URL
        const uniqueConnections = rawList.reduce((acc: SavedConnection[], current) => {
          const existingIndex = acc.findIndex(item => 
            item.supplierName === current.supplierName && 
            item.apiUrl === current.apiUrl
          );
          
          if (existingIndex === -1) {
            // New unique connection
            acc.push(current);
          } else {
            // Duplicate found - keep the most recent one
            const existing = acc[existingIndex];
            const existingDate = existing.updatedAt ? new Date(existing.updatedAt) : new Date(0);
            const currentDate = current.updatedAt ? new Date(current.updatedAt) : new Date(0);
            
            if (currentDate > existingDate) {
              // Replace with newer connection
              acc[existingIndex] = current;
            }
          }
          
          return acc;
        }, []);
        
        console.log(`Removed ${rawList.length - uniqueConnections.length} duplicate connections`);
        console.log('🔍 SupplierListing: Connections with schedule data:', uniqueConnections.map(c => ({
          id: c.id,
          name: c.name,
          scheduleEnabled: c.scheduleEnabled,
          scheduleFrequency: c.scheduleFrequency,
          scheduleTime: c.scheduleTime,
          scheduledTime: c.scheduledTime
        })));
        setConnections(uniqueConnections);
        setTotalImportedProducts(data.totalImportedProducts || 0);
      } else {
        setConnections([]);
        setTotalImportedProducts(0);
      }
    } catch {
      setConnections([]);
    } finally {
      setIsLoadingConnections(false);
    }
  }

  useEffect(() => {
    loadConnections();
  }, []);

  // Mock supplier data
  const suppliers = [
    {
      id: 1,
      name: 'Premium Suppliers Ltd',
      email: 'api@premiumsuppliers.com',
      website: 'https://premiumsuppliers.com',
      status: 'active',
      apiConnections: 2,
      csvConnections: 1,
      totalProducts: 3247,
      lastActivity: '2 hours ago',
      connectionTypes: ['api', 'csv'] as Array<'api' | 'csv'>
    },
    {
      id: 2,
      name: 'Global Wholesale Inc',
      email: 'tech@globalwholesale.net',
      website: 'https://globalwholesale.net',
      status: 'active',
      apiConnections: 1,
      csvConnections: 0,
      totalProducts: 892,
      lastActivity: '1 day ago',
      connectionTypes: ['api'] as Array<'api' | 'csv'>
    },
    {
      id: 3,
      name: 'Fashion Distributors Co',
      email: 'support@fashiondistributors.com',
      website: 'https://fashiondistributors.com',
      status: 'active',
      apiConnections: 0,
      csvConnections: 2,
      totalProducts: 2156,
      lastActivity: '30 minutes ago',
      connectionTypes: ['csv'] as Array<'api' | 'csv'>
    },
    {
      id: 4,
      name: 'Electronics Hub Corp',
      email: 'integration@electronicshub.com',
      website: 'https://electronicshub.com',
      status: 'inactive',
      apiConnections: 1,
      csvConnections: 0,
      totalProducts: 634,
      lastActivity: '3 days ago',
      connectionTypes: ['api'] as Array<'api' | 'csv'>
    },
    {
      id: 5,
      name: 'Beauty Products Direct',
      email: 'api@beautyproductsdirect.com',
      website: 'https://beautyproductsdirect.com',
      status: 'error',
      apiConnections: 0,
      csvConnections: 1,
      totalProducts: 543,
      lastActivity: '1 hour ago',
      connectionTypes: ['csv'] as Array<'api' | 'csv'>
    }
  ];

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return <Badge tone="success">Active</Badge>;
      case 'inactive':
        return <Badge>Inactive</Badge>;
      case 'error':
        return <Badge tone="critical">Error</Badge>;
      default:
        return <Badge>Unknown</Badge>;
    }
  };

  // Filter suppliers based on search term
  const filteredSuppliers = suppliers.filter(supplier =>
    supplier.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    supplier.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Calculate dynamic stats from real connections data
  const totalSuppliers = connections.length > 0 ? 
    new Set(connections.map(c => c.name)).size : 0;
  
  const activeConnections = connections.filter(c => 
    (c.status || '').toLowerCase() === 'connected'
  ).length;
  
  const totalConnections = connections.length;
  
  // Use total imported products from database instead of connection product counts
  const totalProducts = totalImportedProducts;

  // Prepare data for DataTable
  const rows = filteredSuppliers.map((supplier) => [
    supplier.name,
    supplier.email,
    getStatusBadge(supplier.status),
    supplier.apiConnections + supplier.csvConnections,
    supplier.totalProducts.toLocaleString(),
    supplier.lastActivity,
    <ButtonGroup key={supplier.id}>
      <Button onClick={() => onSupplierClick(supplier)}>View Details</Button>
    </ButtonGroup>
  ]);

  const headings = [
    'Supplier Name',
    'Email',
    'Status',
    'Connections',
    'Products',
    'Last Activity',
    'Actions'
  ];

  const handleCardClick = (supplier: any) => {
    navigate('/app/connection-management', { 
      state: { 
        editMode: true, 
        supplierData: supplier 
      } 
    });
  };

  const handleCleanupDuplicates = async () => {
    try {
      const response = await fetch('/app/api/connections', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          action: 'cleanupDuplicates'
        })
      });
      
      const result = await response.json();
      if (result.success) {
        console.log('✅ Duplicates cleaned up:', result.message);
        // Reload suppliers after cleanup
        loadConnections();
      }
    } catch (error) {
      console.error('❌ Error cleaning up duplicates:', error);
    }
  };

  return (
    <Layout>
      {/* Header Stats */}
      <Layout.Section>
        <InlineGrid columns={{ xs: 1, sm: 2, md: 4 }} gap="400">
          <div style={{ background: '#eef5fe', padding: '1rem', border: '1px solid #95b4e7', borderRadius: '10px', color: '#1970ff' }} >
            <Box padding="100">
              <BlockStack gap="100">
                <BlockStack gap="100" inlineAlign="start">
                  <div style={{ textAlign: 'left', display: 'flex', gap: '5px' }}>
                    <Icon source={ClipboardChecklistIcon} tone="info" />
                    <Text as="p" variant="bodyMd" fontWeight="semibold"  >Total Suppliers</Text>
                  </div>
                </BlockStack>
                <Text variant="headingLg" as="p">{totalSuppliers}</Text>
              </BlockStack>
            </Box>
          </div>
          <div style={{ background: '#f0fdf4', padding: '1rem', border: '1px solid #6cb191', borderRadius: '10px' }} >
            <Box padding="100">
              <BlockStack gap="100">
                <BlockStack gap="100" inlineAlign="start">
                  <div style={{ textAlign: 'left', display: 'flex', gap: '5px' }}>
                    <Icon source={StatusActiveIcon} tone="success" />
                    <Text as="p" variant="bodyMd" fontWeight="semibold" tone="success">Active</Text>
                  </div>
                </BlockStack>
                <Text variant="headingLg" as="p" tone="success">{activeConnections}</Text>
              </BlockStack>
            </Box>
          </div>
          <div style={{ background: '#faf5fe', padding: '1rem', border: '1px solid #e9baff', borderRadius: '10px' }} >
            <Box padding="100">
              <BlockStack gap="100">
                <BlockStack gap="100" inlineAlign="start">
                  <div style={{ textAlign: 'left', display: 'flex', gap: '5px' }}>
                    <Icon source={DomainLandingPageIcon} tone="magic" />
                    <Text as="p" variant="bodyMd" fontWeight="semibold" tone="magic">Connections</Text>
                  </div>
                </BlockStack>
                <Text variant="headingLg" as="p" tone='magic'>{totalConnections}</Text>
              </BlockStack>
            </Box>
          </div>



          <div style={{ background: '#fff5ea', padding: '1rem', border: '1px solid #ebab7b', borderRadius: '10px' }} >
            <Box padding="100">
              <BlockStack gap="100">
                <BlockStack gap="100" inlineAlign="start">
                  <div style={{ textAlign: 'left', display: 'flex', gap: '5px' }}>
                    <Icon source={DatabaseIcon} tone="caution" />
                    <Text as="p" variant="bodyMd" fontWeight="semibold" tone="caution">Total Products</Text>
                  </div>
                </BlockStack>
                <Text variant="headingLg" as="p" tone="caution">{totalProducts.toLocaleString()}</Text>
              </BlockStack>
            </Box>
          </div>
        </InlineGrid>
      </Layout.Section>

      {/* Suppliers Management */}
      <Layout.Section>
        <Card>
          <Box padding="600">
            <BlockStack gap="400">
              <InlineStack align="space-between" blockAlign="center">
                <BlockStack>
                  <Text variant="headingMd" as="h2">Supplier Directory</Text>
                  <Text as="p" variant="bodyMd" tone="subdued">
                    Manage your supplier relationships and connection configurations
                  </Text>
                </BlockStack>
                <InlineStack gap="200">
                  <Button
                    variant="secondary"
                    onClick={handleCleanupDuplicates}
                  >
                    Cleanup Duplicates
                  </Button>
                  <Button
                    variant="primary"
                    icon={PlusIcon}
                    onClick={onAddNewSupplier}
                  >
                    Add New Supplier & API
                  </Button>
                </InlineStack>
              </InlineStack>

              {/* Search Bar */}
              <Box>
                <TextField
                  label=""
                  placeholder="Search suppliers by name or email..."
                  value={searchTerm}
                  onChange={setSearchTerm}
                  prefix={<Icon source={SearchIcon} />}
                  clearButton
                  onClearButtonClick={() => setSearchTerm('')}
                  autoComplete="off"
                />
              </Box>

              {/* Connections List (from database) */}
              {filteredSuppliers.length > 0 ? (
                <Card>
                  {connections.length > 0 ? (
                    <BlockStack gap="200">
                      {(() => {
                        // Group connections by supplier name to avoid duplicates
                        const groupedConnections = connections.reduce((acc, c) => {
                          const supplierName = c.name || 'Unknown Supplier';
                          if (!acc[supplierName]) {
                            acc[supplierName] = {
                              name: supplierName,
                              connections: [],
                              totalProducts: 0,
                              lastSync: null,
                              status: 'connected'
                            };
                          }
                          acc[supplierName].connections.push(c);
                          if (typeof c.productCount === 'number') {
                            acc[supplierName].totalProducts += c.productCount;
                          }
                          if (c.updatedAt) {
                            const syncDate = new Date(c.updatedAt);
                            if (!acc[supplierName].lastSync || syncDate > new Date(acc[supplierName].lastSync!)) {
                              acc[supplierName].lastSync = c.updatedAt;
                            }
                          }
                          if (c.status === 'error') {
                            acc[supplierName].status = 'error';
                          }
                          return acc;
                        }, {} as Record<string, any>);

                        // Convert to array and sort by last sync
                        const uniqueSuppliers = Object.values(groupedConnections)
                          .sort((a: any, b: any) => {
                            if (!a.lastSync && !b.lastSync) return 0;
                            if (!a.lastSync) return 1;
                            if (!b.lastSync) return -1;
                            return new Date(b.lastSync).getTime() - new Date(a.lastSync).getTime();
                          });

                        return uniqueSuppliers.map((supplier: any) => {
                          const isConnected = supplier.status === 'connected';
                          const dotColor = isConnected ? '#00c951' : (supplier.status === 'error' ? '#fb2c36' : '#99a1af');
                          const statusLabel = isConnected ? 'Active' : (supplier.status || 'Unknown');
                          const connectionCount = supplier.connections.length;
                          
                          return (
                            <div key={supplier.name} onClick={() => handleCardClick(supplier)} style={{ cursor: 'pointer' }}>
                              <InlineStack align="space-between" blockAlign="center">
                                <InlineStack gap="200" blockAlign="center">
                                  <InlineStack>
                                    <InlineStack blockAlign="center" gap="100">
                                      <p style={{ width: 12, height: 12, background: dotColor, borderRadius: '50%' }} />
                                      <Icon source={StatusActiveIcon} tone={isConnected ? 'success' : 'base'} />
                                    </InlineStack>
                                  </InlineStack>

                                  <InlineStack>
                                    <BlockStack>
                                      <InlineStack gap="200">
                                        <Text variant="bodyLg" as="p" fontWeight="semibold">
                                          {supplier.name} <span style={{ marginLeft: '20px', fontWeight: 400, background: '#d7f5d7', padding: '4px 6px', borderRadius: '50px', fontSize: '10px', color: 'green' }}>{statusLabel}</span>
                                        </Text>
                                      </InlineStack>

                                      <Box paddingBlockStart="100">
                                        <div style={{ display: 'flex', alignItems: 'center' }}>
                                          <Icon
                                            source={EmailIcon}
                                            tone="base"
                                          /> 
                                          {supplier.connections[0]?.apiUrl || supplier.connections[0]?.csvFileName || '—'} 
                                          {connectionCount > 1 && (
                                            <span style={{ marginLeft: '8px', background: '#f0f0f0', padding: '2px 6px', borderRadius: '12px', fontSize: '11px' }}>
                                              +{connectionCount - 1} more
                                            </span>
                                          )}
                                          <span style={{ marginLeft: '20px' }}> 
                                            Last sync: <Text as='span' fontWeight='regular'> {getTimeAgo(supplier.lastSync)}</Text>
                                          </span>
                                        </div>
                                      </Box>
                                    </BlockStack>
                                  </InlineStack>
                                </InlineStack>

                                <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
                                  {supplier.totalProducts > 0 && (
                                    <p style={{ textAlign: 'center' }}>
                                      <b>{supplier.totalProducts.toLocaleString()}</b> <br />
                                      <span>Products</span>
                                    </p>
                                  )}
                                  <ButtonGroup>
                                    <Button 
                                      size="slim" 
                                      variant="secondary"
                                      onClick={() => {
                                        // Edit functionality - navigate to edit page with supplier data
                                        console.log('🚀 Edit button clicked for supplier:', supplier);
                                        // Store supplier data in localStorage as backup
                                        localStorage.setItem('editSupplierData', JSON.stringify(supplier));
                                        // Use URL parameters
                                        const params = new URLSearchParams({
                                          supplier: supplier.name,
                                          editMode: 'true'
                                        });
                                        navigate(`/app/connection-management?${params.toString()}`);
                                      }}
                                    >
                                      Edit
                                    </Button>
                                    <Button 
                                      size="slim" 
                                      variant="secondary"
                                      tone="critical"
                                      onClick={() => {
                                        // Delete functionality - show confirmation dialog
                                        if (confirm(`Are you sure you want to delete all connections for "${supplier.name}"?`)) {
                                          // Delete all connections for this supplier
                                          supplier.connections.forEach(async (connection: any) => {
                                            try {
                                              await fetch(`/app/api/connections/${connection.id}`, {
                                                method: 'DELETE'
                                              });
                                            } catch (error) {
                                              console.error('Error deleting connection:', error);
                                            }
                                          });
                                          // Reload connections after deletion
                                          loadConnections();
                                        }
                                      }}
                                    >
                                      Delete
                                    </Button>
                                  </ButtonGroup>
                                  <Icon
                                    source={ChevronRightIcon}
                                    tone="base"
                                  />
                                </div>
                              </InlineStack>
                            </div>
                          );
                        });
                      })()}
                    </BlockStack>
                  ) : (
                    <Box paddingBlockStart="400" paddingBlockEnd="400">
                      <Text as="p" tone="subdued">{isLoadingConnections ? 'Loading connections...' : 'No connections found.'}</Text>
                    </Box>
                  )}
                </Card>
              ) : (
                <Box paddingBlockStart="800" paddingBlockEnd="800">
                  <EmptyState
                    heading={searchTerm ? `No suppliers found matching "${searchTerm}"` : "No suppliers yet"}
                    image="https://cdn.shopify.com/s/files/1/0262/4071/2726/files/emptystate-files.png"
                    action={{
                      content: searchTerm ? 'Clear search' : 'Add New Supplier & API',
                      onAction: searchTerm ? () => setSearchTerm('') : onAddNewSupplier,
                    }}
                  >
                    {!searchTerm && (
                      <p>Click "Add New Supplier & API" to get started</p>
                    )}
                  </EmptyState>
                </Box>
              )}
            </BlockStack>
          </Box>
        </Card>
      </Layout.Section>
    </Layout>
  );
}