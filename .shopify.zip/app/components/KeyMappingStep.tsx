import {useState, useMemo, useEffect} from "react";
import {
  Page,
  Card,
  Layout,
  Text,
  Box,
  BlockStack,
  InlineStack,
  Button,
  Select,
  Badge,
  Icon,
  TextField,
  InlineGrid,
  Divider
} from "@shopify/polaris";
import {
  ArrowLeftIcon,
  ArrowRightIcon,
  PlusIcon,
  DeleteIcon,
  LinkIcon,
  DatabaseIcon,
  CartIcon
} from "@shopify/polaris-icons";
import {useNavigate} from "@remix-run/react"; 

// ---- helpers ----
function toOptions(values: string[]) {
  return values.map((v) => ({label: v, value: v}));
}

function uniqFilter(values: string[], taken: Set<string>) {
  return values.filter((v) => !taken.has(v));
}

interface KeyMappingStepProps {
  mappings: Record<string, string>;
  onMappingsChange: (next: Record<string, string>) => void;
  dataSource: 'api' | 'csv';
  apiCredentials?: { apiUrl: string; accessToken: string };
  csvData: any;
  onNext: () => void;
  onPrevious: () => void;
}

export default function KeyMappingStep({
  mappings,
  onMappingsChange,
  dataSource,
  apiCredentials,
  csvData,
  onNext,
  onPrevious,
}: KeyMappingStepProps) {
  const [showPreview, setShowPreview] = useState(false);
  const navigate = useNavigate();

  const [sourceFields, setSourceFields] = useState<string[]>([]);
  const [isLoadingFields, setIsLoadingFields] = useState(false);

  // Saved connections loaded from the database
  type SavedConnection = {
    id: string;
    name: string;
    type: 'api' | 'csv' | string;
    apiUrl?: string | null;
    csvFileName?: string | null;
    status?: string | null;
    updatedAt?: string | null;
  };
  const [connections, setConnections] = useState<SavedConnection[]>([]);
  const [isLoadingConnections, setIsLoadingConnections] = useState(false);
  const [connectionsError, setConnectionsError] = useState<string | null>(null);

  function getTimeAgo(dateInput?: string | null) {
    if (!dateInput) return '—';
    const date = new Date(dateInput);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffSec = Math.floor(diffMs / 1000);
    const diffMin = Math.floor(diffSec / 60);
    const diffHr = Math.floor(diffMin / 60);
    const diffDay = Math.floor(diffHr / 24);
    if (diffSec < 60) return 'just now';
    if (diffMin < 60) return `${diffMin} min${diffMin === 1 ? '' : 's'} ago`;
    if (diffHr < 24) return `${diffHr} hour${diffHr === 1 ? '' : 's'} ago`;
    return `${diffDay} day${diffDay === 1 ? '' : 's'} ago`;
  }

  async function loadConnections() {
    setIsLoadingConnections(true);
    setConnectionsError(null);
    try {
      const resp = await fetch('/app/api/connections');
      const data = await resp.json();
      if (resp.ok && data?.success) {
        const list: SavedConnection[] = (data.connections || []).map((c: any) => ({
          id: c.id,
          name: c.name,
          type: c.type,
          apiUrl: c.apiUrl ?? null,
          csvFileName: c.csvFileName ?? null,
          status: c.status ?? 'connected',
          updatedAt: c.updatedAt ?? null,
        }));
        setConnections(list);
      } else {
        setConnections([]);
        setConnectionsError(typeof data?.error === 'string' ? data.error : 'Failed to load connections');
      }
    } catch (e) {
      setConnections([]);
      setConnectionsError('Failed to load connections');
    } finally {
      setIsLoadingConnections(false);
    }
  }

  async function fetchApiSourceFields() {
    if (!apiCredentials?.apiUrl || !apiCredentials?.accessToken) return;
    setIsLoadingFields(true);
    try {
      const formData = new FormData();
      formData.append('action', 'fetchSampleFields');
      formData.append('apiUrl', apiCredentials.apiUrl);
      formData.append('accessToken', apiCredentials.accessToken);
      const resp = await fetch('/app/api/external', { method: 'POST', body: formData });
      const data = await resp.json();
      if (resp.ok && data?.success) {
        setSourceFields(Array.isArray(data.fields) ? data.fields : []);
      } else {
        setSourceFields([]);
      }
    } catch {
      setSourceFields([]);
    } finally {
      setIsLoadingFields(false);
    }
  }

  // Load fields on mount if API
  useEffect(() => {
    if (dataSource === 'api') {
      fetchApiSourceFields();
    } else {
      // Derive from CSV header when CSV is the source
      if (csvData && Array.isArray(csvData.headers)) {
        setSourceFields(csvData.headers);
      } else {
        setSourceFields([]);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dataSource, apiCredentials?.apiUrl, apiCredentials?.accessToken]);

  // Load saved connections once so we can show a simple list for reference
  useEffect(() => {
    loadConnections();
  }, []);

  const shopifyFields = [
    "title *",
    "body_html",
    "vendor",
    "product_type",
    "tags",
    "price *",
    "compare_at_price",
    "inventory_quantity",
    "weight",
    "weight_unit",
    "sku *",
    "barcode",
    "requires_shipping",
    "taxable",
    "status",
    "image_src",
    "option1_name",
    "option1_value",
    "option2_name",
    "option2_value",
    "option3_name",
    "option3_value",
  ];

  type Row = { id: string; source: string; target: string };
  const [rows, setRows] = useState<Row[]>([{ id: crypto.randomUUID(), source: "", target: "" }]);

  const mappedCount = useMemo(() => rows.filter(r => r.source && r.target).length, [rows]);

  // Persist mappings upward whenever rows change
  useEffect(() => {
    const nextMappings: Record<string, string> = {};
    for (const r of rows) {
      if (r.source && r.target) {
        nextMappings[r.source] = r.target;
      }
    }
    onMappingsChange(nextMappings);
  }, [rows, onMappingsChange]);

  const takenSources = useMemo(
    () => new Set(rows.map((r) => r.source).filter(Boolean)),
    [rows]
  );
  const takenTargets = useMemo(
    () => new Set(rows.map((r) => r.target).filter(Boolean)),
    [rows]
  );

  const sourceOptions = useMemo(
    () => toOptions(uniqFilter(sourceFields, takenSources)),
    [sourceFields, takenSources]
  );
  const targetOptions = useMemo(
    () => toOptions(uniqFilter(shopifyFields, takenTargets)),
    [shopifyFields, takenTargets]
  );

  function addRow() {
    setRows((prev) => [...prev, { id: crypto.randomUUID(), source: "", target: "" }]);
  }

  function removeRow(id: string) {
    setRows((prev) => prev.filter((r) => r.id !== id));
  }

  function updateRow(id: string, key: keyof Row, value: string) {
    setRows((prev) =>
      prev.map((r) => (r.id === id ? { ...r, [key]: value } : r))
    );
  }

  const canProceed = mappedCount > 0;

  // Validation logic for required fields
  const requiredFields = ['title *', 'price *', 'sku *'];
  const mappedTargets = rows.map(r => r.target).filter(Boolean);
  const missingRequiredFields = requiredFields.filter(field => !mappedTargets.includes(field));
  const hasRequiredFields = missingRequiredFields.length === 0;
  
  // Show validation error if required fields are missing
  const showValidationError = mappedCount > 0 && !hasRequiredFields;

  return (
    <Card>
    <Page
      title="Step 2: Key Mapping"
      subtitle="Map your API fields to Shopify product attributes using dropdown selectors"
    >
      <Layout>
        {/* KPI Strip */}
         <Layout.Section>
              <InlineGrid columns={{ xs: 1, sm: 2, md: 3 }} gap="400">
                <div style={{ background: '#faf5fe', padding: '1rem', border: '1px solid #e9baff', borderRadius: '10px' }} >
                  <Box padding="100">
                    <BlockStack gap="100">
                      <BlockStack gap="100" inlineAlign="start">
                        <div style={{ textAlign: 'left', display: 'flex',alignItems:'center', gap: '5px' }}> 
                          <Icon source={DatabaseIcon} tone="magic" /> 
                          <Text as="p" variant="bodySm" fontWeight="semibold" tone="magic" >Source Fields</Text>
                        </div>
                      </BlockStack>
                      <Text variant="headingLg" as="p" tone="magic">{sourceFields.length}</Text>
                      <Text variant="headingXs" as="p" tone="magic">Available sources</Text>
                    </BlockStack>
                  </Box>
                </div>
             
                <div style={{ background: '#eef5fe', padding: '1rem', border: '1px solid #95b4e7', borderRadius: '10px', color: '#1970ff' }} >
                  <Box padding="100">
                    <BlockStack gap="100">
                      <BlockStack gap="100" inlineAlign="start">
                        <div style={{ textAlign: 'left', display: 'flex', gap: '5px' }}>
                          <Icon source={CartIcon} tone="info" />
                          <Text as="p" variant="bodyMd" fontWeight="semibold"  >Shopify Fields</Text>
                        </div>
                      </BlockStack>
                      <Text variant="headingLg" as="p" >{shopifyFields.length}</Text>
                      <Text variant="headingXs" as="p"  >Available targets</Text>

                    </BlockStack>
                  </Box>
                </div> 

                   <div style={{ background: '#f0fdf4', padding: '1rem', border: '1px solid #6cb191', borderRadius: '10px' }} >
                  <Box padding="100">
                    <BlockStack gap="100">
                      <BlockStack gap="100" inlineAlign="start">
                        <div style={{ textAlign: 'left', display: 'flex', gap: '5px' }}>
                          <Icon source={LinkIcon} tone="success" />
                          <Text as="p" variant="bodyMd" fontWeight="semibold" tone="success">Mapped</Text>
                        </div>
                      </BlockStack>
                      <Text variant="headingLg" as="p" tone="success">{mappedCount}</Text>
                      <Text variant="headingXs" as="p" tone="success">Active mappings</Text>

                    </BlockStack>
                  </Box>
                </div>
              </InlineGrid>
            </Layout.Section>

        {/* Field Mappings */}
        <Layout.Section>
          <Card>
            <Box padding="400">
              <BlockStack gap="300">
                <InlineStack align="space-between" blockAlign="center">
                  <Text as="h3" variant="headingMd">Field Mappings</Text>
                  {dataSource === 'api' && (
                    <Button variant="tertiary" onClick={fetchApiSourceFields} loading={isLoadingFields}>
                      Refresh Source Fields
                    </Button>
                  )}
                  <Button icon={PlusIcon} onClick={addRow}>Add Mapping</Button>
                </InlineStack>

                <div style={{ background: '#fff3cd', border: '1px solid #ffeaa7', borderRadius: '8px', padding: '12px' }}>
                  <Text as="p" variant="bodySm">
                    <strong>Required Fields:</strong> title *, price *, sku * - These fields are required for product creation. 
                    Make sure to map at least these three fields.
                  </Text>
                </div>

                {showValidationError && (
                  <div style={{ background: '#f8d7da', border: '1px solid #f5c6cb', borderRadius: '8px', padding: '12px' }}>
                    <Text as="p" variant="bodySm" tone="critical">
                      <strong>Missing Required Fields:</strong> Please map the following required fields: {missingRequiredFields.join(', ')}
                    </Text>
                  </div>
                )}

                <Divider />

                <InlineGrid columns={{xs: 1, md: 2}} gap="200" alignItems="center">
                  <Text as="h4" variant="bodyMd" fontWeight="semibold">SOURCE FIELD</Text>
                  <Text as="h4" variant="bodyMd" fontWeight="semibold">SHOPIFY FIELD</Text>
                  <Box />
                </InlineGrid>

                {/* rows */}
                <BlockStack gap="200">
                  {rows.map((row) => (
                    <div style={{border:'1px solid #ccc', padding:'10px', borderRadius:'10px'}}>
                    <InlineGrid key={row.id} columns={{xs: 1, md: 2}} gap="200" alignItems="center">
                      <Select
                        label="Select source field"
                        labelHidden
                        options={row.source ? toOptions([row.source]).concat(sourceOptions) : sourceOptions}
                        value={row.source}
                        onChange={(v) => updateRow(row.id, "source", v)}
                        placeholder="Select source field"
                      />
                      <div style={{display:'flex', alignItems:'center', gap:'10px'}}>
                      <div style={{width:'90%'}}>

                      <Select
                        label="Select Shopify field"
                        labelHidden
                        options={row.target ? toOptions([row.target]).concat(targetOptions) : targetOptions}
                        value={row.target}
                        onChange={(v) => updateRow(row.id, "target", v)}
                        placeholder="Select Shopify field"
                       />
                       </div>
                      <div>
                        <Button icon={DeleteIcon} onClick={() => removeRow(row.id)} accessibilityLabel="Remove mapping" />
                      </div>
                      </div>
                    </InlineGrid>
                    </div>
                  ))}
                </BlockStack>
              </BlockStack>
            </Box>
          </Card>
        </Layout.Section>



        {/* Footer Nav */}
        <Layout.Section>
          <InlineStack gap="300">
            <Button   icon={ArrowLeftIcon} onClick={onPrevious}>
              Previous Step
            </Button>
            <Button  
              icon={ArrowRightIcon} 
              onClick={onNext}
              disabled={!canProceed || !hasRequiredFields}
            >
              Next Step
            </Button>
          </InlineStack>
        </Layout.Section>
      </Layout>
    </Page>
    </Card>
  );
}
