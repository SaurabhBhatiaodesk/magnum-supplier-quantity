import {
  Card,
  Layout,
  Button,
  RadioButton, 
  BlockStack,
  Text,
  Box,
  ButtonGroup,
  Divider,
  InlineStack
} from '@shopify/polaris';
import {
  ArrowLeftIcon,
  ArrowRightIcon,
  PackageIcon,
  FilterIcon,
  FileIcon
} from '@shopify/polaris-icons';

type ImportType = 'all' | 'attribute';

interface ImportTypeStepProps {
  importType: ImportType;
  onImportTypeChange: (value: ImportType) => void;
  onNext: () => void;
  onPrevious: () => void;
}

export default function ImportTypeStep({
  importType,
  onImportTypeChange,
  onNext,
  onPrevious
}: ImportTypeStepProps) {

  const importOptions = [
    {
      value: 'all',
      title: 'Import All Products',
      description: 'Import all available products from the data source',
      icon: PackageIcon,
      recommended: false
    }
  ];

  return (
    <Layout>
      <Layout.Section>
        <Card>
          <Box padding="600">
            <BlockStack gap="400">
              <InlineStack align="space-between" blockAlign="center">
                <div> 
                <Text variant="headingMd" as="h3">Step 3: Import Configuration</Text>
                <Text as="p" variant="bodyMd" tone="subdued">
                  Configure your product import settings
                </Text>
                </div>
                <Button icon={FileIcon}>Save Progress</Button>
              </InlineStack> 

              <BlockStack gap="200">
                <Text variant="headingMd" as="h2">Import Configuration</Text>
                
                <div  style={{ background: '#eef5fe', padding: '1rem', border: '3px solid #95b4e7', borderRadius: '10px', color: '#1970ff' }}>
                  {importOptions.map((option) => (
                    
                       <InlineStack   blockAlign="center">
                        <RadioButton
                          label=""
                          checked={importType === option.value}
                          id={option.value}
                          name="importType"
                          onChange={() => onImportTypeChange(option.value as ImportType)}
                        />
                        
                        <BlockStack gap="100" inlineAlign="stretch">
                          <BlockStack gap="100" >
                            <Text variant="headingSm" as="h3">{option.title}</Text>
                            {option.recommended && (
                              <Box>
                                <Text as="span" variant="bodySm" tone="success" fontWeight="semibold">
                                  Recommended
                                </Text>
                              </Box>
                            )}
                          </BlockStack>
                          
                          <Text as="p" variant="bodyMd" tone="subdued">
                            {option.description}
                          </Text>
                          
                          {option.value === 'all' && (
                            <Box>
                              <Text as="p" variant="bodySm" tone="subdued">
                                Best for: First-time imports, small product catalogs, or when you want everything from the supplier.
                              </Text>
                            </Box>
                          )}
                          
                          {option.value === 'attribute' && (
                            <Box>
                              <Text as="p" variant="bodySm" tone="subdued">
                                Best for: Large catalogs, specific product categories, or when you only want products matching certain criteria.
                              </Text>
                            </Box>
                          )}
                        </BlockStack>
                      </InlineStack>
                     
                  ))}
                </div>
              </BlockStack>

              <BlockStack align="end">
                <ButtonGroup>
                  <Button 
                    
                    icon={ArrowLeftIcon}
                    onClick={onPrevious}
                  >
                    Previous
                  </Button>
                  
                  <Button 
                    variant="primary"
                    icon={ArrowRightIcon}
                    onClick={onNext}
                    disabled={!importType}
                  >
                    Next: Key Mapping
                  </Button>
                </ButtonGroup>
              </BlockStack>
            </BlockStack>
          </Box>
        </Card>
      </Layout.Section>
    </Layout>
  );
}