import { useState } from 'react';
import { json, LoaderFunctionArgs } from '@remix-run/node';
import { useLoaderData } from '@remix-run/react';
import { authenticate } from '../shopify.server';
import {
  Page,
  Card,
  Layout,
  Badge,
  Button,
  ProgressBar,
  Text,
  Icon,
  Box,
  BlockStack,
  InlineStack,
  Divider
} from '@shopify/polaris';
import { CheckCircleIcon, ChevronRightIcon } from '@shopify/polaris-icons';

// Import step components
import SupplierListingStep from '../components/SupplierListingStep';
import SupplierDetailsStep from '../components/SupplierDetailsStep';
import ApiCredentialsStep from '../components/ApiCredentialsStep';
import KeyMappingStep from '../components/KeyMappingStep';
import ImportTypeStep from '../components/ImportTypeStep';
import ImportFilterStep from '../components/ImportFilterStep';
import MarkupConfigurationStep from '../components/MarkupConfigurationStep';
import ImportConfigurationStep from '../components/ImportConfigurationStep';
import ImportProcessStep from '../components/ImportProcessStep';
import CsvImportStep from '../components/CsvImportStep';
import ProgressSteps from '../components/ProgressSteps';
import AppCsvFile from '../components/AppCsvFile';

export async function loader({ request }: LoaderFunctionArgs) {
  await authenticate.admin(request);
  return null;
}

export default function Index() {
  type ImportType = 'all' | 'attribute';
  type DataSource = 'api' | 'csv';
  type ImportConfig = 'draft' | 'published';
  type MarkupCondition = {
    id: string;
    attribute: string;
    operator: 'equals' | 'contains' | 'greater_than' | 'less_than' | 'between';
    value: string;
    markupType: 'percentage' | 'fixed';
    markupValue: string;
    priority: number;
  };
  type MarkupConfig = {
    conditions: MarkupCondition[];
    conditionsType: 'all' | 'any';
    tieBreaker: 'higher' | 'lower' | 'priority';
  };

  const [currentStep, setCurrentStep] = useState(1);
  const [showApiList, setShowApiList] = useState(false);
  const [showSupplierListing, setShowSupplierListing] = useState(true);
  const [showSupplierDetails, setShowSupplierDetails] = useState(false);
  const [selectedSupplier, setSelectedSupplier] = useState<any>(null);
  const [editingApi, setEditingApi] = useState(null);
  const [dataSource, setDataSource] = useState<DataSource>('api');
  const [showCsvImport, setShowCsvImport] = useState(false);
  const [apiCredentials, setApiCredentials] = useState({
    apiUrl: '',
    accessToken: ''
  });
  const [csvData, setCsvData] = useState(null);
  const [keyMappings, setKeyMappings] = useState<Record<string, string>>({});
  const [importType, setImportType] = useState<ImportType>('all');
  const [importFilters, setImportFilters] = useState<{ selectedAttributes: string[]; selectedValues: string[] }>({
    selectedAttributes: [],
    selectedValues: []
  });
  const [markupConfig, setMarkupConfig] = useState<MarkupConfig>({
    conditions: [],
    conditionsType: 'all',
    tieBreaker: 'higher'
  });
  const [importConfig, setImportConfig] = useState<ImportConfig>('draft');
  const [isImporting, setIsImporting] = useState(false);
  const [productCount, setProductCount] = useState(0);

  const steps = [
    { number: 1, title: 'Data Source', description: 'Choose API or CSV import' },
    { number: 2, title: 'Import Configuration', description: 'Configure import settings' },
    { number: 3, title: 'Key Mapping', description: 'Map data fields to Shopify keys' },
    { number: 4, title: 'Import Filters', description: 'Filter products to import' },
    { number: 5, title: 'Markup Configuration', description: 'Configure pricing markup rules' },
    { number: 6, title: 'Import Settings', description: 'Choose draft vs published import' },
    { number: 7, title: 'Import Process', description: 'Start importing products' }
  ];

  const handleNextStep = () => {
    if (currentStep < 7) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePreviousStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleAddNewApi = () => {
    setShowApiList(false);
    setShowSupplierListing(false);
    setShowSupplierDetails(false);
    setEditingApi(null);
    setApiCredentials({ apiUrl: '', accessToken: '' });
  };

  const handleEditApi = (api:any) => {
    setShowApiList(false);
    setShowSupplierListing(false);
    setShowSupplierDetails(false);
    setEditingApi(api);
    setApiCredentials({ apiUrl: api.url, accessToken: '' });
  };

  const handleGoToApiList = () => {
    setShowApiList(true);
    setShowSupplierListing(false);
    setShowSupplierDetails(false);
    setEditingApi(null);
  };

  const handleSupplierClick = (supplier: any) => {
    setSelectedSupplier(supplier);
    setShowSupplierListing(false);
    setShowSupplierDetails(true);
    setShowApiList(false);
  };

  const handleGoBackToSupplierListing = () => {
    setShowSupplierListing(true);
    setShowSupplierDetails(false);
    setSelectedSupplier(null);
    setShowApiList(false);
  };

  const handleAddNewSupplier = () => {
    handleAddNewApi();
  };

  const handleAddNewConnection = (supplier: any) => {
    setSelectedSupplier(supplier);
    handleAddNewApi();
  };

  const handleCompleteImport = () => {
    setCurrentStep(1);
    setShowSupplierListing(true);
    setShowApiList(false);
    setShowSupplierDetails(false);
    setSelectedSupplier(null);
    setEditingApi(null);
    setIsImporting(false);
    setShowCsvImport(false);
    setDataSource('api');
    setApiCredentials({ apiUrl: '', accessToken: '' });
    setCsvData(null);
    setKeyMappings({});
    setImportFilters({ selectedAttributes: [], selectedValues: [] });
    setMarkupConfig({ conditions: [], conditionsType: 'all', tieBreaker: 'higher' });
    setImportConfig('draft');
    setProductCount(0);
  };

  const handleImportCsv = () => {
    setShowCsvImport(true);
    setShowApiList(false);
    setShowSupplierListing(false);
    setShowSupplierDetails(false);
  };

  const handleCsvImported = (data:any) => {
    setCsvData(data);
    setDataSource('csv');
    setShowCsvImport(false);
    setShowApiList(false);
    setShowSupplierListing(false);
    setShowSupplierDetails(false);
    setCurrentStep(2);
  };

  const handleGoBackToApiList = () => {
    setShowCsvImport(false);
    if (showSupplierDetails && selectedSupplier) {
      setShowSupplierDetails(true);
    } else {
      setShowSupplierListing(true);
    }
  };

  const getStepIcon = (stepNumber:any) => {
    if (stepNumber < currentStep) {
      return <Icon source={CheckCircleIcon} tone="success" />;
    }
    return null;
  };

  const getCurrentStepInfo = () => {
    return steps.find(step => step.number === currentStep);
  };

  const renderCurrentStep = () => {
    switch (currentStep) {
      case 1:
        if (showSupplierListing) {
          return (
            <SupplierListingStep
              onSupplierClick={handleSupplierClick}
              onAddNewSupplier={handleAddNewSupplier}
            />
          );
        } else if (showSupplierDetails && selectedSupplier) {
          return (
            <SupplierDetailsStep
              supplier={selectedSupplier}
              onGoBack={handleGoBackToSupplierListing}
              onAddNewConnection={handleAddNewConnection}
            />
          );
        } else if (showCsvImport) {
          return (
            <CsvImportStep
              onCsvImported={handleCsvImported}
              onGoBack={handleGoBackToApiList}
            />
          );
        } else {
          return (
            <ApiCredentialsStep
              credentials={apiCredentials}
              onCredentialsChange={setApiCredentials}
              onNext={selectedSupplier ? () => setShowSupplierDetails(true) : (editingApi ? handleGoToApiList : handleNextStep)}
              onGoToList={handleGoBackToSupplierListing}
              editingApi={editingApi}
              onConnectionTypeChange={(type) => setDataSource(type)}
              onSelectCsvImport={() => {
                setShowCsvImport(true);
                setShowApiList(false);
                setShowSupplierListing(false);
                setShowSupplierDetails(false);
              }}
            />
          );
        }
      case 2:
        return (
          <ImportTypeStep
            importType={importType}
            onImportTypeChange={setImportType}
            onNext={handleNextStep}
            onPrevious={handlePreviousStep}
          />
        );
      case 3:
        return (
          <KeyMappingStep
            mappings={keyMappings}
            onMappingsChange={setKeyMappings}
            dataSource={dataSource}
            apiCredentials={apiCredentials}
            csvData={csvData}
            onNext={handleNextStep}
            onPrevious={handlePreviousStep}
          />
        );
      case 4:
        return (
          <ImportFilterStep
            filters={importFilters}
            onFiltersChange={(next) => setImportFilters(next)}
            importType={importType}
            dataSource={dataSource}
            apiCredentials={apiCredentials}
            csvData={csvData}
            mappings={keyMappings}
            onNext={handleNextStep}
            onPrevious={handlePreviousStep}
            onProductCountChange={setProductCount}
          />
        );
      case 5:
        return (
          <MarkupConfigurationStep
            apiCredentials={apiCredentials}
            onNext={handleNextStep}
            onPrevious={handlePreviousStep}
            value={{
              conditions: (markupConfig.conditions || []).map((c) => {
                const operatorMap: Record<string, string> = {
                  equals: 'eq',
                  contains: 'contains',
                  greater_than: 'eq',
                  less_than: 'eq',
                  between: 'between',
                };
                const mappedOperator = operatorMap[c.operator] || 'eq';
                const isPercent = c.markupType === 'percentage';
                const presetCandidates = ['10','15','20','25','30','50'];
                const isPreset = isPercent && presetCandidates.includes(c.markupValue);
                return {
                  id: c.id,
                  field: c.attribute || 'tag',
                  operator: mappedOperator,
                  tagText: c.value || '',
                  markupType: isPercent ? 'percent' : 'fixed',
                  percentagePreset: isPercent ? (isPreset ? c.markupValue : 'custom') : '10',
                  customPercent: isPercent ? (isPreset ? '' : c.markupValue) : '',
                  value: isPercent ? (isPreset ? c.markupValue : (c.markupValue || '')) : (c.markupValue || '0'),
                } as any;
              }),
              conditionsType: markupConfig.conditionsType,
              tieBreaker: markupConfig.tieBreaker,
            }}
            selectedFiltersSummary={(() => {
              const attrSet = new Set(importFilters?.selectedAttributes || []);
              const map = new Map<string, Set<string>>();
              // Initialize all selected attributes with empty sets
              for (const a of attrSet) {
                map.set(a, new Set<string>());
              }
              // Fill values from selectedValues tokens
              for (const token of (importFilters?.selectedValues || [])) {
                const [key, val] = token.split('::');
                if (!key) continue;
                if (!map.has(key)) map.set(key, new Set<string>());
                if (val) map.get(key)!.add(val);
              }
              // Convert to array format
              return Array.from(map.entries()).map(([key, set]) => ({ key, values: Array.from(set) }));
            })()}
            onChange={(cfg) => {
              setMarkupConfig({
                conditions: (cfg?.conditions ?? []).map((c, idx) => ({
                  id: c.id || String(idx),
                  attribute: (c as any).field || 'tag',
                  operator: ((): any => {
                    const rev: Record<string, any> = { 
                      eq: 'equals', 
                      contains: 'contains',
                      between: 'between'
                    };
                    return rev[(c as any).operator] || 'equals';
                  })(),
                  value: (c as any).tagText ?? '',
                  markupType: ((c as any).markupType === 'percent' ? 'percentage' : 'fixed') as any,
                  markupValue: ((): string => {
                    if ((c as any).markupType === 'percent') {
                      return (c as any).percentagePreset === 'custom' ? ((c as any).customPercent || '0') : ((c as any).percentagePreset || '0');
                    }
                    return (c as any).value || '0';
                  })(),
                  priority: idx + 1,
                })),
                conditionsType: cfg?.conditionsType ?? 'all',
                tieBreaker: markupConfig.tieBreaker,
              });
            }}
          />
        );
      case 6:
        return (
          <ImportConfigurationStep
            config={importConfig}
            onConfigChange={setImportConfig}
            onNext={handleNextStep}
            onPrevious={handlePreviousStep}
          />
        );
      case 7:
        return (
          <ImportProcessStep
            dataSource={dataSource}
            apiCredentials={apiCredentials}
            csvData={csvData}
            keyMappings={keyMappings}
            importFilters={importFilters}
            markupConfig={markupConfig}
            importConfig={importConfig}
            productCount={productCount}
          />
        );
      default:
        return null;
    }
  };

  const currentStepInfo = getCurrentStepInfo();
  const progressValue = Math.round((currentStep / 7) * 100);

  const getPageTitle = () => {
    if (currentStep === 1 && showSupplierListing) {
      return 'Supplier Management Dashboard';
    } else if (currentStep === 1 && showSupplierDetails) {
      return 'Supplier Connection Details';
    } else if (currentStep === 1 && showCsvImport) {
      return 'CSV Import';
    } else {
      return `Step ${currentStep} of ${steps.length}: ${currentStepInfo?.title}`;
    }
  };

  return (
    <Page
      title="Product Import Manager"
      subtitle="Import products from external APIs to your Shopify store"
      primaryAction={{
        content: `Step ${currentStep} of 7`,
        disabled: true
      }}
    >
      <Layout>
        {/* Progress Steps - Hide when on supplier management screens */}
        {!(currentStep === 1 && (showSupplierListing || showSupplierDetails || showCsvImport)) && (
          <Layout.Section>
            <ProgressSteps currentStep={currentStep} steps={steps} />
          </Layout.Section>
        )}

        {/* Current Step Content */}
        <Layout.Section>
          {renderCurrentStep()}
        </Layout.Section>
      </Layout>
      <AppCsvFile />
    </Page>
  );
}